SPOOL C:\temp\_CreateProblemSolutionApp.log

SET CONCAT +

SET VERIFY OFF
SET TERMOUT OFF
DEFINE core_db = ''
COLUMN name NEW_VALUE core_db
SELECT name
  FROM v$database;
SET TERMOUT ON

-- The following must run from the schema that will own the Problem/Solution tables and code
PROMPT Cleaning up previous installations...
DROP TABLE ps_sol CASCADE CONSTRAINTS PURGE;
DROP TABLE ps_prob CASCADE CONSTRAINTS PURGE;
DROP TABLE ps_prob_src PURGE;
DROP SEQUENCE ps_prob_seq;
DROP SEQUENCE ps_sol_seq;
DROP SEQUENCE ps_prob_src_seq;

PROMPT Creating new objects...
CREATE SEQUENCE ps_prob_src_seq;
CREATE SEQUENCE ps_prob_seq;
CREATE SEQUENCE ps_sol_seq;

CREATE TABLE ps_prob_src
(
 prob_src_id INTEGER NOT NULL
,prob_src_nm VARCHAR2(30 CHAR) NOT NULL
,prob_src_defn VARCHAR2(255 CHAR) NOT NULL
,display_order NUMBER NOT NULL
,active_flg VARCHAR2(1 BYTE) DEFAULT 'Y' NOT NULL
,prnt_prob_src_id INTEGER
,CONSTRAINT ps_prob_src_pk PRIMARY KEY (prob_src_id)
,CONSTRAINT ps_prob_src_uk UNIQUE (prob_src_nm)
,CONSTRAINT pps_active_flg_chk CHECK (active_flg IN ('Y','N'))
,CONSTRAINT pps_prnt_prob_src_id_fk FOREIGN KEY (prnt_prob_src_id) REFERENCES ps_prob_src (prob_src_id)
)
/
CREATE INDEX pps_prnt_prob_src_id_idx ON ps_prob_src(prnt_prob_src_id)
/
COMMENT ON TABLE ps_prob_src IS 'Problem Source: User-amendable list of the various sources of problems encountered in an IT shop.';
COMMENT ON COLUMN ps_prob_src.prob_src_id IS 'Problem Source ID: Surrogate key for this table. Currently filled manually by data population scripts.';
COMMENT ON COLUMN ps_prob_src.prob_src_nm IS 'Problem Source Value: Name or code for the source system, environment, hardware or software from which the error was first detected or originated.';
COMMENT ON COLUMN ps_prob_src.prob_src_defn IS 'Problem Source Definition: Full definition of the source system, environment, hardware or software from which the error was first detected or originated.';
COMMENT ON COLUMN ps_prob_src.display_order IS 'Display Order: In case the users wish one set of values to be ordered in a non-alphabetical manner, this allows them to customize the ordering of values.';
COMMENT ON COLUMN ps_prob_src.active_flg IS 'Active Flag: Flag that indicates if the record is active (Y) or not (N).';
COMMENT ON COLUMN ps_prob_src.prnt_prob_src_id IS 'Parent Problem Source ID: Self-referring foreign key. Filled if the sources of problems become so numerous that categorization or hierarchy is needed.';

CREATE TABLE ps_prob
(
 prob_id INTEGER NOT NULL
,prob_key VARCHAR2(50 CHAR) NOT NULL
,prob_key_txt VARCHAR2(4000 CHAR)
,prob_notes VARCHAR2(4000 CHAR)
,prob_src_id INTEGER
,otx_sync_col VARCHAR2(1 BYTE) DEFAULT 'N' NOT NULL
,CONSTRAINT ps_prob_pk PRIMARY KEY (prob_id)
,CONSTRAINT ps_prob_uk UNIQUE (prob_key, prob_key_txt)
,CONSTRAINT ps_prob_src_id_fk FOREIGN KEY (prob_src_id) REFERENCES ps_prob_src (prob_src_id)
)
/
CREATE INDEX psp_prob_src_id_idx ON ps_prob(prob_src_id)
/
COMMENT ON TABLE ps_prob IS 'Problem: Record of the errors, issues and problems encountered day-to-day.';
COMMENT ON COLUMN ps_prob.prob_id IS 'Problem ID: Surrogate key for records in this table.';
COMMENT ON COLUMN ps_prob.prob_key IS 'Problem Key: Typically the OS, Database, or application-specific error
 ID or name. Usually found at the top of an error stack, or in the title of error and warning dialogs. If
 this problem is not related to an identifiable error, give the problem a short name or code which
 adequately identifies the situation.';
COMMENT ON COLUMN ps_prob.prob_key_txt IS 'Problem Key Text: Optional. Typically the error message that came
 with the error ID, minus the specific non-repeatable, contextual information.';
COMMENT ON COLUMN ps_prob.prob_notes IS 'Problem Notes: You could use this field to store context surrounding
 the problem, like time of day it was observed, environment, concurrent processes, contacts, vendor case
 IDs, etc.';
COMMENT ON COLUMN ps_prob.prob_src_id IS 'Problem Source ID: Optional ID of the problem source. FK to PS_PROB_SRC.';
COMMENT ON COLUMN ps_prob.otx_sync_col IS 'Oracle Text Sync Column: A dummy column used as both the base column for multi-column context indexes, as well as the column that must be updated to Y whenever any data is changed or added so that the Oracle Text CTX_DDL.sync procedure will pick up the changes.';

CREATE TABLE ps_sol
(
 sol_id INTEGER NOT NULL
,prob_id INTEGER NOT NULL
,sol_notes VARCHAR2(4000)
,CONSTRAINT ps_sol_pk PRIMARY KEY (sol_id)
,CONSTRAINT pss_prob_id_fk FOREIGN KEY (prob_id) REFERENCES ps_prob (prob_id)
)
/
COMMENT ON TABLE ps_sol IS 'Solution: Record of the possible solutions to a given problem. Some problems 
 will have only one solutions, others may have several alternatives.';
COMMENT ON COLUMN ps_sol.sol_id IS 'Solution ID: Surrogate key for records in this table.';
COMMENT ON COLUMN ps_sol.prob_id IS 'Problem ID: Foreign key to PS_PROB.';
COMMENT ON COLUMN ps_sol.sol_notes IS 'Solution Notes: Steps to take to solve the related problem.';

CREATE INDEX pss_prob_id_idx ON ps_sol (prob_id)
/

PROMPT Populating new objects...
INSERT INTO ps_prob_src (prob_src_id, prob_src_nm, prob_src_defn, display_order, active_flg, prnt_prob_src_id)
VALUES (ps_prob_src_seq.nextval,  'ORA Errors', 'Oracle Errors of all kinds (ORA, PLS, TNS, etc.)', 1, 'Y', NULL);
INSERT INTO ps_prob_src (prob_src_id, prob_src_nm, prob_src_defn, display_order, active_flg, prnt_prob_src_id)
VALUES (ps_prob_src_seq.nextval,'Oracle Database','Problems with Oracle Database Server',1.1,'Y',1);
INSERT INTO ps_prob_src (prob_src_id, prob_src_nm, prob_src_defn, display_order, active_flg, prnt_prob_src_id)
VALUES (ps_prob_src_seq.nextval,'Oracle EPG','Problems with Oracle Embedded PL/SQL Gateway',1.2,'Y',1);
INSERT INTO ps_prob_src (prob_src_id, prob_src_nm, prob_src_defn, display_order, active_flg, prnt_prob_src_id)
VALUES (ps_prob_src_seq.nextval,'Oracle Text','Problems using Oracle Text',1.3,'Y',1);
INSERT INTO ps_prob_src (prob_src_id, prob_src_nm, prob_src_defn, display_order, active_flg, prnt_prob_src_id)
VALUES (ps_prob_src_seq.nextval,  'Windows', 'Windows error messages, shortcuts, tips and tricks.', 2, 'Y', NULL);
INSERT INTO ps_prob_src (prob_src_id, prob_src_nm, prob_src_defn, display_order, active_flg, prnt_prob_src_id)
VALUES (ps_prob_src_seq.nextval,  'Shell', 'Problems working with shell scripts.', 3, 'Y', NULL);
INSERT INTO ps_prob_src (prob_src_id, prob_src_nm, prob_src_defn, display_order, active_flg, prnt_prob_src_id)
VALUES (ps_prob_src_seq.nextval,  'Linux', 'Linux annoyances.', 4, 'Y', NULL);
INSERT INTO ps_prob_src (prob_src_id, prob_src_nm, prob_src_defn, display_order, active_flg, prnt_prob_src_id)
VALUES (ps_prob_src_seq.nextval,  'Java', 'Issues workinng with Java.', 5, 'Y', NULL);
INSERT INTO ps_prob_src (prob_src_id, prob_src_nm, prob_src_defn, display_order, active_flg, prnt_prob_src_id)
VALUES (ps_prob_src_seq.nextval,  'SubVersion', 'Problems with Subversion.', 6, 'Y', NULL);
INSERT INTO ps_prob_src (prob_src_id, prob_src_nm, prob_src_defn, display_order, active_flg, prnt_prob_src_id)
VALUES (ps_prob_src_seq.nextval,  'App Server', 'Issues with the application server.', 7, 'Y', NULL);
COMMIT;

--------------------------------------------------------------------------------
INSERT INTO ps_prob
   (prob_id
   ,prob_key
   ,prob_key_txt
   ,prob_notes
   ,prob_src_id
   ,otx_sync_col)
VALUES
   (ps_prob_seq.nextval
   ,'ORA-03113'
   ,'End-of-file on communication channel (Network connection lost)'
   ,'Common error encountered when connection to the database is severed.'
   ,1
   ,'Y');

INSERT INTO ps_sol
   (sol_id
   ,prob_id
   ,sol_notes)
VALUES
   (ps_sol_seq.nextval
   ,(SELECT prob_id FROM ps_prob WHERE prob_key = 'ORA-03113')
   ,'This error sometimes happens when you encounter nasty bugs in Oracle. 
   But the most typical explanation for a 3113 is that something about the network between you and the database went sour. 
   Check your cable or wireless. 
   Ensure the database host and database are still reachable with ping and tnsping.
   Usually a 3113 just goes away when you try to connect again.');

--------------------------------------------------------------------------------
INSERT INTO ps_prob
   (prob_id
   ,prob_key
   ,prob_key_txt
   ,prob_notes
   ,prob_src_id
   ,otx_sync_col)
VALUES
   (ps_prob_seq.nextval
   ,'TNS-12523'
   ,'TNS:listener could not find instance appropriate for the client connection.'
   ,'Encountered this error in the listener.log of both 10g XE and 10g EE when attempting to contact the EPG over http, port 8080.'
   ,1
   ,'Y');

INSERT INTO ps_sol
   (sol_id
   ,prob_id
   ,sol_notes)
VALUES
   (ps_sol_seq.nextval
   ,(SELECT prob_id FROM ps_prob WHERE prob_key = 'TNS-12523')
   ,'One solution to this problem turned out to be a local client firewall (Sophos). It had a default configuration from 
   corporate HQ engineering that prevented http requests. Both turning off the firewall and later getting engineering to
   put me in the special Oracle group where that sort of traffic was allowed solved my problem.');

--------------------------------------------------------------------------------
INSERT INTO ps_prob
   (prob_id
   ,prob_key
   ,prob_key_txt
   ,prob_notes
   ,prob_src_id
   ,otx_sync_col)
VALUES
   (ps_prob_seq.nextval
   ,'DAD Not Reachable'
   ,'Attempts to reach procs in the schema behind the DAD returned nothing. No 404 error page. No HTML whatsoever. Just a blank page.'
   ,'Mainly tried changing the port being used by the EPG to listen for HTTP traffic. No luck. 
   Tried the same with Oracle XE which comes with a built-in setup for HTTP traffic to support APEX. Still didn''t work.'
   ,2
   ,'Y');

INSERT INTO ps_sol
   (sol_id
   ,prob_id
   ,sol_notes)
VALUES
   (ps_sol_seq.nextval
   ,(SELECT prob_id FROM ps_prob WHERE prob_key = 'DAD Not Reachable')
   ,'No error message or returned HTML should have been a big clue that the HTTP request was not reaching the EPG.
   Checking the Windows application log didn''t help. Finally checked the laptop''s firewall client logs 
   and found tnslsnr.exe and oracle.exe were being rejected by the firewall. Got the engineering group to
   add me to a special Oracle group that allows that kind of TCP traffic on my laptop. EPG is working fine now.');   

--------------------------------------------------------------------------------
INSERT INTO ps_prob
   (prob_id
   ,prob_key
   ,prob_key_txt
   ,prob_notes
   ,prob_src_id
   ,otx_sync_col)
VALUES
   (ps_prob_seq.nextval
   ,'printjoins'
   ,''
   ,'Using the printjoins attribute of the Oracle Text lexer preference does not seem to be working. Indexing
   with printjoins in the lexer does not complain and the tokens in the underlying DR$ index table seem fine.
   But attempts to search with the CONTAINS operator don''t yield expected results. This is true for both
   dashes and underscore characters.'
   ,3
   ,'Y');

INSERT INTO ps_sol
   (sol_id
   ,prob_id
   ,sol_notes)
VALUES
   (ps_sol_seq.nextval
   ,(SELECT prob_id FROM ps_prob WHERE prob_key = 'printjoins')
   ,'You must escape the "-" or "_" characters if the user inputs them in the search string in order for the CONTAINS operator to see them and include them in the search against the Context index.');   

--------------------------------------------------------------------------------
INSERT INTO ps_prob
   (prob_id
   ,prob_key
   ,prob_key_txt
   ,prob_notes
   ,prob_src_id
   ,otx_sync_col)
VALUES
   (ps_prob_seq.nextval
   ,'Explorer Stinks'
   ,'Much functionality was lost with Windows NT 3.51 File Explorer. Really miss double panes.'
   ,''
   ,4
   ,'Y');

INSERT INTO ps_sol
   (sol_id
   ,prob_id
   ,sol_notes)
VALUES
   (ps_sol_seq.nextval
   ,(SELECT prob_id FROM ps_prob WHERE prob_key = 'Explorer Stinks')
   ,'Download and enjoy FreeCommander. http://www.freecommander.com. Has everything a developer needs.');   
INSERT INTO ps_sol
   (sol_id
   ,prob_id
   ,sol_notes)
VALUES
   (ps_sol_seq.nextval
   ,(SELECT prob_id FROM ps_prob WHERE prob_key = 'Explorer Stinks')
   ,'You could also try eXplorer2 from zabkat.');   

COMMIT;
 
PROMPT Compiling packages...
SET DEFINE OFF
@@ps_dml.pks
@@ps_ui.pks
@@ps_ctx.pks
@@ps_ui.pkb
@@ps_dml.pkb
@@ps_ctx.pkb
@@_otx_prefs_and_index.sql
SET DEFINE ON

SPOOL OFF
SET VERIFY ON
